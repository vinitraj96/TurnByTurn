package com.turnbyturn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class GameOver extends Activity {

    TextView playerWon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);
        Intent in=getIntent();
        playerWon= (TextView) findViewById(R.id.playerWonTextView);
        playerWon.setText(in.getStringExtra("player_won") + " Won");
    }

    @Override
    public void onBackPressed() {
        Intent in=new Intent(this,MainActivity.class);
        startActivity(in);
    }

    public void onClickRestart(View v){
        Intent in=new Intent(this,MainActivity.class);
        startActivity(in);
    }
}
