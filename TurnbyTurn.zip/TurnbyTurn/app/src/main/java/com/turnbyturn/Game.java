package com.turnbyturn;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Game extends Activity {

    String no_of_tiles_string;
    int no_of_tiles_int;
    GridLayout grid_layout;
    TextView[] text;
    int item;
    TextView p_one,p_two,playerChance;
    int p_one_touch,p_two_touch,total_touch;
    int i=0;
    int  n;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        grid_layout= (GridLayout) findViewById(R.id.grid_layout);
        playerChance= (TextView) findViewById(R.id.playerChance);
        p_one= (TextView) findViewById(R.id.p_one);
        p_two= (TextView) findViewById(R.id.p_two);
        Intent in=getIntent();
        no_of_tiles_string=in.getStringExtra("no_of_tiles");
        Toast.makeText(this,no_of_tiles_string,Toast.LENGTH_LONG).show();
        if(no_of_tiles_string.equals("two")){
            no_of_tiles_int=2;
        }else if(no_of_tiles_string.equals("three")){
            no_of_tiles_int=3;
        }else if(no_of_tiles_string.equals("four")){
            no_of_tiles_int=4;
        }else if(no_of_tiles_string.equals("five")){
            no_of_tiles_int=5;
        }else if(no_of_tiles_string.equals("six")){
            no_of_tiles_int=6;
        }else if(no_of_tiles_string.equals("seven")){
            no_of_tiles_int=7;
        }else if(no_of_tiles_string.equals("eight")){
            no_of_tiles_int=8;
        }
        grid_layout.setColumnCount(no_of_tiles_int);
        grid_layout.setRowCount(no_of_tiles_int);
        text = new TextView[no_of_tiles_int*no_of_tiles_int];
        for(int i=0;i<no_of_tiles_int*no_of_tiles_int;i++)
        {
            text[i] = new TextView(Game.this);
            text[i].setText("F");
            text[i].setTextSize(25);
            text[i].setId(i);
            text[i].setLayoutParams(new LayoutParams
                    (LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            text[i].setPadding(50, 25, 10, 25);
            text[i].setBackgroundColor(Color.GRAY);
            text[i].setTextColor(Color.BLUE);
            grid_layout.addView(text[i]);
        }
        Random rand = new Random();

        n = rand.nextInt(no_of_tiles_int*no_of_tiles_int) + 1;

        text[n].setTextColor(Color.YELLOW);
        for(item=0;item<no_of_tiles_int*no_of_tiles_int;item++) {
            text[item].setOnClickListener(new View.OnClickListener() {

                int pos = item;
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    if(n==pos){
                        if(i==0){
                            i=1;
                            p_one_touch=p_two_touch+1;
                            p_one.setText("P1:"+Integer.toString(p_one_touch));
                            playerChance.setText("Player Two");
                        }else{
                            i=0;
                            p_two_touch=p_two_touch+1;
                            p_two.setText("P2:"+Integer.toString(p_two_touch));
                            playerChance.setText("Player One");
                        }
                        for(int i=0;i<no_of_tiles_int*no_of_tiles_int;i++)
                        {
                            text[i].setBackgroundColor(Color.GRAY);
                            text[i].setTextColor(Color.BLUE);
                        }

                        Random rand = new Random();

                        n = rand.nextInt(no_of_tiles_int*no_of_tiles_int) + 1;

                        text[n].setTextColor(Color.YELLOW);

                    }else{
                        Intent in=new Intent(Game.this,GameOver.class);
                        if(playerChance.getText().toString().equals("Player One")){
                            in.putExtra("player_won","Player Two");
                        }else{
                            in.putExtra("player_won","Player One");
                        }
                        startActivity(in);
                        //Toast.makeText(Game.this,"Game Over: "+playerChance.getText().toString() +" Lost",Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }
}
